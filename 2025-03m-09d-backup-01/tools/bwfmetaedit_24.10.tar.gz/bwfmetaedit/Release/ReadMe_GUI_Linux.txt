BWF MetaEdit
------------
This code was created in 2010 for the Library of Congress and the other federal government agencies participating in the Federal Agencies Digital Guidelines Initiative and it is in the public domain.

Usage
-----
bwfmetaedit-gui


Compilation from source
-----------------------
* at the top of the archive, ./GUI_Compile.sh
or
* cd Project/GNU/GUI/, ./configure, ./make

