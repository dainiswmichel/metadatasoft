#! /bin/sh
./GUI_Compile.sh
